# Notes on ETL2PCAPNG

ETL2PCAPNG is a conversion tool written to convert ETL files to a wireshark readable pcapng extension. The project is can be found on github here: https://github.com/microsoft/etl2pcapng